<template lang="pug">
.curso-main-container.pb-3
  BannerInterno
  .container.tarjeta.tarjeta--blanca.p-4.p-md-5.mb-5
    .titulo-principal.color-acento-contenido
      .titulo-principal__numero
        span 3
      h1 Alimentos en la nutrición de los bovinos

    .row.justify-content-center(data-aos="fade-up")
      .col-xl-4.col-lg-5.col-md-8.align-content-center.order-xl-1.order-lg-2
        figure
          img.my-3(src='@/assets/curso/temas/tema3/img1.png', alt='Imagen decorativa')
      .col-xl-8.col-lg-12.order-xl-2.order-lg-1
        p.mb-3 Los bovinos son muy versátiles en cuanto a la alimentación, esto quiere decir que se les puede suministrar una variedad de alimentos. El más conocido es el pasto, pero este no aporta todos los nutrientes que el animal necesita por lo que se hace importante que el productor ganadero conozca las diferentes alternativas nutricionales como son: 
        .row.justify-content-center
          .col-lg-6.col-md-6.crd--avatarHorizontal-left-bgr4.py-3.mb-3.m-auto
            .row.align-items-center.top
              .col-auto(style="z-index:1")
                figure
                  img(src="@/assets/curso/temas/tema3/img2.svg", alt="", width= "60px", height="60px")
              .col(style="z-index:1")
                p.mb-0 Forrajes
          .col-lg-6.col-md-6.crd--avatarHorizontal-left-bgr4.py-3.mb-3.m-auto
            .row.align-items-center.top
              .col-auto(style="z-index:1")
                figure
                  img(src="@/assets/curso/temas/tema3/img2.svg", alt="", width= "60px", height="60px")
              .col(style="z-index:1")
                p.mb-0 Subproductos de la agroindustria
        .row.justify-content-center
          .col-lg-6.col-md-6.crd--avatarHorizontal-left-bgr4.py-3.mb-3.m-auto
            .row.align-items-center.top
              .col-auto(style="z-index:1")
                figure
                  img(src="@/assets/curso/temas/tema3/img2.svg", alt="", width= "60px", height="60px")
              .col(style="z-index:1")
                p.mb-0 Suplementos
          .col-lg-6.col-md-6.crd--avatarHorizontal-left-bgr4.py-3.mb-3.m-auto
            .row.align-items-center.top
              .col-auto(style="z-index:1")
                figure
                  img(src="@/assets/curso/temas/tema3/img2.svg", alt="", width= "60px", height="60px")
              .col(style="z-index:1")
                p.mb-0 Leguminosas
          .col-lg-6.col-md-6.crd--avatarHorizontal-left-bgr4.py-3.mb-3.m-auto
            .row.align-items-center.top
              .col-auto(style="z-index:1")
                figure
                  img(src="@/assets/curso/temas/tema3/img2.svg", alt="", width= "60px", height="60px")
              .col(style="z-index:1")
                p.mb-0 Especies arbóreas

    
    .row.justify-content-center.fondo-imagen-5
      .col-lg-12
        .row.mt-5.mb-4.align-items-center(data-aos="fade-left")
          .col-auto
            img(src='@/assets/curso/temas/tema1/img2.svg', alt='Imagen decorativa')
          .col.px-0
            h3.mb-0 Forrajes

        p.my-3 Los forrajes son plantas o residuos de cosecha que sirven de alimento para los bovinos. Las especies forrajeras se caracterizan por contener gran cantidad de agua en su masa vegetal y es una buena alternativa porque les aporta nutrientes, además de ser económico para el productor ganadero.


        .row.justify-content-center(data-aos="flip-up")
          .col-lg-9.fnd.align-content-center
            p.mb-2 <strong>Las plantas forrajeras se dividen en:</strong>
            ul.mt-0
              li
                span Gramíneas.
            ul.mt-0
              li
                span Leguminosas.
            p.mb-2 <strong>Los forrajes se pueden clasificar por su contenido de agua en:</strong>
            ul.mt-0
              li
                span Los forrajes verdes: son pastos de corte y son suministrados al animal cuando están en punto de cosecha.
            ul.mt-0
              li
                span Forrajes secos: estos se ponen a secar y se conocen como henos.
            p.mt-2 La forma más conocida de utilizar forrajes es suministrarlo al animal picado y en pastoreo.
          .col-lg-3.col-md-8.align-content-center.h-100
            img(src='@/assets/curso/temas/tema3/img8.png', alt='Imagen decorativa')
        .row.justify-content-center
          .col-lg-10
            .row.justify-content-center
              .col-lg-12.order-lg-2.order-md-1(data-aos="fade-left")
                h5.mt-4.green_icon(data-aos="fade-left") Valor nutritivo de los forrajes
                  img.my-3(src='@/assets/curso/temas/tema3/green_icon-2.svg', alt='Imagen decorativa')
                
                .row.justify-content-center.fnd-2
                  .col-lg-9
                    p.mb-2 <strong>El valor nutritivo de las plantas forrajeras depende de tres factores:</strong>
                    ul.mt-0 
                      li
                        span Composición química.
                    ul.mt-0 
                      li
                        span Digestibilidad.
                    ul.mt-0 
                      li
                        span Palatabilidad.
                  .col-lg-3.col-md-8
                    img(src='@/assets/curso/temas/tema3/img9.svg', alt='Imagen decorativa')
                
    
                p.my-3 Los forrajes están constituidos fundamentalmente por carbohidratos, proteínas, grasas, minerales (macroelementos y microelementos) y vitaminas.
        
            h5.mt-4.green_icon(data-aos="fade-left") Carbohidratos
              img.my-3(src='@/assets/curso/temas/tema3/green_icon-2.svg', alt='Imagen decorativa')
            
            p.my-3(data-aos="fade-up") Estos compuestos en las especies forrajeras se encuentran en gran cantidad, sin embargo, los bovinos lo sintetizan de diferente manera de acuerdo con su digestión. Por ejemplo, los azúcares y ácidos orgánicos son digeridos en un 100 % por los microorganismos ruminales; para los almidones y pectinas solubles la digestibilidad oscila entre el 80 y 100 %; en la hemicelulosa oscila entre un 20 y 60 %.
            p.my-3(data-aos="fade-up") Por ello, se puede afirmar que los carbohidratos son los responsables de aportar la mitad de la energía que requieren los rumiantes. Los forrajes como las gramíneas contienen más azúcares que muchas leguminosas, porque crecen en climas templados. Por ejemplo, el fructosano es un carbohidrato que está presente en las gramíneas de clima templado o frío y el almidón es un carbohidrato de reserva de las gramíneas tropicales.


                
            h5.mt-4.green_icon(data-aos="fade-left") Proteínas
              img.my-3(src='@/assets/curso/temas/tema3/green_icon-2.svg', alt='Imagen decorativa')
            
            p.my-3 Este compuesto en los forrajes es variado y cada proteína se comporta de forma diferente tanto en el rumen como en el intestino, por eso se pueden clasificar de acuerdo con su estructura y a la forma en que se fermentan y se absorben dentro del animal. A continuación, se describe su comportamiento:
            
            .row.justify-content-center.align-items-center.mb-3(data-aos="zoom-in")
              .col-lg-3.col-md-5.my-3
                figure
                  img.my-3(src="@/assets/curso/temas/tema3/img11.png")(style="min-height: 300px")
              .col-lg-9.col-md-12
                SlyderF.custom(columnas="col-lg-6 col-md-6")
                  .tarjeta.tarjeta--slyder.p-4.fnd-4
                    p.mb-0 <strong>Fracción A1:</strong> incluye el nitrógeno no proteico que es soluble presente en la planta y forma parte de ésta principalmente en: aminoácidos libres, pequeños péptidos y nitratos que son fuente inmediata de nitrógeno para microorganismos.
                  .tarjeta.tarjeta--slyder.p-4.fnd-4
                    p.mb-0 <strong>Fracción B1:</strong> incluye las proteínas solubles que son fermentadas casi en su totalidad en el rumen. Son fuente inmediata de nitrógeno, igual que la clasificación anterior, pero su tasa de degradación es más lenta.
                  .tarjeta.tarjeta--slyder.p-4.fnd-4
                    p.mb-0 <strong>Fracción B2:</strong> comprende la porción de proteínas que no es soluble y no está ligada a la fibra, su taza de degradación es más lenta que las anteriores.
                  .tarjeta.tarjeta--slyder.p-4.fnd-4
                    p.mb-0 <strong>Fracción B3:</strong> comprende la porción de la proteína de la pared celular que es potencialmente degradada en el rumen.
                  .tarjeta.tarjeta--slyder.p-4.fnd-4
                    p.mb-0 <strong>Fracción C:</strong> constituye la proteína que está ligada a la fibra y se considera que es digerible.
            
            h5.mt-4.green_icon(data-aos="fade-left") Grasas
              img.my-3(src='@/assets/curso/temas/tema3/green_icon-2.svg', alt='Imagen decorativa')
            
            p.my-3 El contenido de este compuesto en los forrajes es bajo y no es representativo porque presenta escasa digestibilidad en los rumiantes.
            
            h5.mt-4.green_icon(data-aos="fade-left") Minerales
              img.my-3(src='@/assets/curso/temas/tema3/green_icon-2.svg', alt='Imagen decorativa')
            
            .row.pe-lg-3.justify-content-center.align-items-center.my-2
              .col-auto.pe-2.img-l.d-none.d-lg-block
                img(src="@/assets/curso/temas/tema3/img10.svg")
              .col
                p.my-3 Los forrajes contienen entre un 5 y 10% de cenizas, en las gramíneas se encuentran cuando la planta alcanza su madurez y en las leguminosas es constante a través del ciclo del cultivo. 
                
            p.my-3 Los minerales presentes en los forrajes se dividen en microelementos y macroelementos.
            
        .row.justify-content-center
          .col-lg-10
            h5.mt-4.green_icon(data-aos="fade-left") Macroelementos
              img.my-3(src='@/assets/curso/temas/tema3/green_icon-2.svg', alt='Imagen decorativa')

            p.my-3 En este grupo se encuentran el calcio, fósforo, potasio, magnesio, sodio, cloro, azufre y silíceo. A continuación, se explica de manera breve:

            .row.justify-content-center.mb-3.mt-4.fondo-imagen3.p-4
              .tarjeta.tarjeta--blanca.p-4(data-aos="fade-up")
                SlyderA(tipo="b")
                  .row.px-3.pt-3
                    .col-lg-6.mb-4.mb-md-0.align-content-center
                      p <strong>Calcio:</strong> en forrajes varía de un 0,3 a un 2,5% y en plantas jóvenes se encuentra en mayor cantidad. En leguminosas se halla más que en gramíneas. El calcio ayuda a la fijación del nitrógeno y al desarrollo radicular.<br>
                    .col-lg-6.align-content-center
                      figure
                        img(src='@/assets/curso/temas/tema3/img14.png', alt='Imagen decorativa')
                  .row.px-3.pt-3
                    .col-lg-6.mb-4.mb-md-0.align-content-center
                      p <strong>Fósforo:</strong> se encuentra en forrajes en un rango de 0,1 a 0,5% siendo abundante en hojas y tallos, ayuda al desarrollo radicular y supervivencia de la planta.<br>
                    .col-lg-6.align-content-center
                      figure
                        img(src='@/assets/curso/temas/tema3/img15.png', alt='Imagen decorativa')
                  .row.px-3.pt-3
                    .col-lg-6.mb-4.mb-md-0.align-content-center
                      p <strong>Magnesio:</strong> este elemento en forrajes varía de 0,1 a 0,7% y la deficiencia de este elemento en la dieta de los rumiantes produce hipomagnesemia, es decir, un desorden metabólico por bajos contenidos de este elemento en la sangre. El magnesio está relacionado de algún modo con el metabolismo de los carbohidratos.<br>
                    .col-lg-6.align-content-center
                      figure
                        img(src='@/assets/curso/temas/tema3/img16.png', alt='Imagen decorativa')
                  .row.px-3.pt-3
                    .col-lg-6.mb-4.mb-md-0.align-content-center
                      p <strong>Azufre:</strong> los forrajes contienen entre 0,1 y 0,4%, los microorganismos presentes en el rumen utilizan sulfatos para realizar síntesis de proteínas.<br>
                    .col-lg-6.align-content-center
                      figure
                        img(src='@/assets/curso/temas/tema3/img17.png', alt='Imagen decorativa')
                  .row.px-3.pt-3
                    .col-lg-6.mb-4.mb-md-0.align-content-center
                      p <strong>Potasio:</strong> este elemento se encuentra en forrajes entre 1 y 4% y disminuye a medida que la planta va envejeciendo, en leguminosas se halla en más cantidad que en gramíneas. Cuando los bovinos consumen hierbas tiernas están ingiriendo más cantidad de potasio, lo que puede producir un efecto laxante.<br>
                    .col-lg-6.align-content-center
                      figure
                        img(src='@/assets/curso/temas/tema3/img18.png', alt='Imagen decorativa')
                  .row.px-3.pt-3
                    .col-lg-6.mb-4.mb-md-0.align-content-center
                      p <strong>Sodio y cloro:</strong> estos elementos se encuentran en los forrajes en forma de sales, pero no están en cantidades suficientes para suplir las necesidades de los bovinos.<br>
                    .col-lg-6.align-content-center
                      figure
                        img(src='@/assets/curso/temas/tema3/img19.png', alt='Imagen decorativa')
                  .row.px-3.pt-3
                    .col-lg-6.mb-4.mb-md-0.align-content-center
                      p <strong>Silíceo:</strong> es absorbido por las raíces de las plantas, en las gramíneas se acumula más que en leguminosas, buena parte de este elemento se almacena en la pared celular de la planta, lo cual dificulta la digestibilidad por parte del animal.<br>
                    .col-lg-6.align-content-center
                      figure
                        img(src='@/assets/curso/temas/tema3/img20.png', alt='Imagen decorativa')
              p.mt-3.text-dark.mb-0.text-center <strong>Fuente: Evangelista (2011).</strong> 
        
            h5.mt-4.green_icon(data-aos="fade-left") Microelementos
              img.my-3(src='@/assets/curso/temas/tema3/green_icon-2.svg', alt='Imagen decorativa')

            p.my-3 Los Microelementos, forman parte del sistema enzimático y hormonal, como por ejemplo el Hierro es constituyente de la hemo globina. El Calcio, Magnesio y Fósforo, forman los huesos, siendo estos la reserva ó el acumulador del Ca y P. Igualmente están el zinc, cobre, manganeso, yodo, hierro, selenio y cobalto. Cuando la ingestión de alguno de ellos no es suficiente, el organismo la toma de esas reservas satisfaciendo momentáneamente los requerimientos.
        .row.justify-content-center
          .col-lg-10
            h5.mt-4.green_icon(data-aos="fade-left") Vitaminas
              img.my-3(src='@/assets/curso/temas/tema3/green_icon-2.svg', alt='Imagen decorativa')
            p.my-3 En los forrajes se encuentran los carotenos, que al ser digeridos por el organismo del animal los convierte en vitaminas, que son indispensables para el desarrollo, crecimiento y salubridad de los bovinos.

        h5.mt-4.green_icon(data-aos="fade-left") Modelos de suministro de forraje
          img.my-3(src='@/assets/curso/temas/tema3/green_icon-2.svg', alt='Imagen decorativa')
        p.my-3 El forraje es el alimento del ganado bovino y está constituido por pastos, heno y raíces. Un suministro constante de forraje de alta calidad representa una sólida base para tener un hato saludable de bovinos y se convierte en un factor fundamental para que el negocio de la ganadería sea rentable, tanto en el caso de la producción de carne como en el de la leche. 
        p.my-3 La importancia del forraje crea la necesidad de realizar una adecuada planificación en cuanto a su producción y así mismo, que esta coincida con la capacidad de la finca y con los requerimientos nutricionales del ganado que se tiene.

        TabsC.color-primario
          .p-4(style="background: #F6F0EA")(titulo="Bancos forrajeros")
            .row.justify-content-center
              .col-lg-9.col-md-12.mb-4.mb-md-0.align-content-center
                p.mb-2 Una forma de obtener fuentes alternas de energía y proteína para el ganado es mediante la utilización de bancos forrajeros, que corresponden a un área de la finca ganadera destinada a la siembra de forraje de alta calidad o de algún otro material que sirva como suplemento alimenticio para el ganado.
                p.mb-2 A lo largo de todo el año se produce alimento en este lugar, que se conserva para ser utilizado en las épocas críticas en las que la producción de la finca se vea afectada. En los periodos donde la disponibilidad de comida disminuye o la calidad del forraje se ve afectada, las reservas de forraje óptimo son utilizadas para suplementar la dieta del ganado, mejorando su nutrición para que mantenga una condición productiva estable.
                p Los bancos forrajeros demandan una inversión de capital que inicialmente puede parecer un costo adicional sin beneficios, sin embargo, en el momento en que el prado del potrero no puede cumplir con los requerimientos nutricionales del  animal, la inversión se recupera al evitarse grandes pérdidas de dinero por disminuciones de productividad.
              .col-md-5.col-lg-3.align-content-center
                figure
                  img.my-3(src='@/assets/curso/temas/tema3/img21.png', alt='Texto que describa la imagen')(style="min-height: 300px")
          
          .p-4(style="background: #F6F0EA")(titulo="Forraje de flujo")
            .row.justify-content-center
              .col-md-12.col-lg-7.align-content-center
                p.mb-2 Indica la cantidad de forraje disponible en cada una de las fuentes presentes en la finca durante cada mes.
                p El modelo de planificación debe estar orientado a igualar las cargas del forraje de flujo con el consumo mensual de alimento por parte del ganado, naturalmente esto no resulta una tarea fácil, sin embargo, es posible emplear algunas estrategias para alcanzar dicho objetivo, entre las cuales se encuentra el sacrificio estratégico de ganado o la planificación de partos, además es posible planear excesos de producción de forraje para ciertas épocas del año, en donde la demanda de alimento se incrementa. 
              .col-md-6.col-lg-5.mb-4.mb-md-0.align-content-center.justify-content-center
                figure
                  img.my-3(src='@/assets/curso/temas/tema3/img22.png', alt='Texto que describa la imagen')
                  




</template>

<script>
export default {
  name: 'Tema3',
  data: () => ({
    // variables de vue
  }),
  mounted() {
    this.$nextTick(() => {
      this.$aosRefresh()
    })
  },
  updated() {
    this.$aosRefresh()
  },
}
</script>

<style lang="sass"></style>
