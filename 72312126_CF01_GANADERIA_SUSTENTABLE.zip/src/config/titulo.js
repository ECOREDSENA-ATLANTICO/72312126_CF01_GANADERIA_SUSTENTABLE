module.exports = 'Generalidades de la ganadería sustentable'
